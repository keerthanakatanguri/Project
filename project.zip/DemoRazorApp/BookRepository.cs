﻿using DemoRazorApp.Models;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace DemoRazorApp
{
    public class BookRepository : IRepository<TblBook>
    {
        private readonly DemoRazorAppContext _appContext;
        public BookRepository()
        {
            _appContext = new DemoRazorAppContext();
        }

        /// <summary>
        /// Inserts a new Book
        /// </summary>
        /// <param name="data"></param>
        public void Add(TblBook data)
        {
            var pTitle = new SqlParameter("@pTitle", data.Title ?? "");
            var pAuthor = new SqlParameter("@pAuthor", data.Author ?? "");
            var pPubYear = new SqlParameter("@pPubYear", data.PublicationYear);
            var pGenre = new SqlParameter("@pGenre", data.Genre ?? "");

            _appContext.Database.ExecuteSqlRaw("EXEC spAddBook @pTitle, @pAuthor, @pPubYear, @pGenre", pTitle, pAuthor, pPubYear, pGenre);
        }

        /// <summary>
        /// Delete a book
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public bool Delete(int Id)
        {
            bool isSuccess;
            try
            {
                _appContext.Database.ExecuteSqlRaw("EXEC spDeleteBook @id", new SqlParameter("@id", Id));
                isSuccess = true;
            }
            catch (Exception ex)
            {
                isSuccess = false;
            }
            return isSuccess;
        }

        /// <summary>
        /// Return all the books
        /// </summary>
        /// <returns></returns>
        public IEnumerable<TblBook> GetAll()
        {
            List<TblBook> books = _appContext.TblBooks.FromSqlRaw("EXEC spGetAllBooks").ToList();
            return books;
        }

        /// <summary>
        /// Get a specific book by ID aka BookId
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public TblBook GetById(int Id)
        {
            var bookId = new SqlParameter("@Id", Id);

            var result = _appContext.TblBooks.FromSqlRaw("EXEC spGetBookById @id", bookId).AsEnumerable().FirstOrDefault();
            return result ?? new TblBook();
        }

        /// <summary>
        /// Update the existing book
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public int Update(TblBook data)
        {
            var pId = new SqlParameter("@pId", data.Id);
            var pTitle = new SqlParameter("@pTitle", data.Title ?? "");
            var pAuthor = new SqlParameter("@pAuthor", data.Author ?? "");
            var pPubYear = new SqlParameter("@pPubYear", data.PublicationYear);
            var pGenre = new SqlParameter("@pGenre", data.Genre ?? "");

            _appContext.Database.ExecuteSqlRaw("EXEC spUpdateBook @pId, @pTitle, @pAuthor, @pPubYear, @pGenre", pId, pTitle, pAuthor, pPubYear, pGenre);
            return data.Id;
        }
    }
}
