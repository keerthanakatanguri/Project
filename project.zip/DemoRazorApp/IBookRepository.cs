﻿using DemoRazorApp.Models;

namespace DemoRazorApp
{
    public interface IRepository<T>
    {
        void Add(T data);
        int Update(T data);
        IEnumerable<T> GetAll();
        T GetById(int Id);
        bool Delete(int Id);
    }
}
