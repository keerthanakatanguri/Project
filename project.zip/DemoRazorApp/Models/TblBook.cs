﻿using System;
using System.Collections.Generic;

namespace DemoRazorApp.Models;

public partial class TblBook
{
    public int Id { get; set; }

    public string Title { get; set; } = null!;

    public string Author { get; set; } = null!;

    public int PublicationYear { get; set; }

    public string? Genre { get; set; }

    public DateTime CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }
}
