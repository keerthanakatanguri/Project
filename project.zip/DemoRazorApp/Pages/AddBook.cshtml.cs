using DemoRazorApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DemoRazorApp.Pages
{
    public class AddBookModel : PageModel
    {
        private  readonly BookRepository _bookRepository;
        public AddBookModel()
        {
            _bookRepository = new BookRepository();
        }

        [BindProperty]
        public TblBook Book { get; set; } = new TblBook();
        public void OnGet(int id)
        {
            if (id != 0)
            {
                Book = _bookRepository.GetById(id);
            }
        }

        public IActionResult OnPost()
        {
            TblBook book = new TblBook()
            {
                Id = Book.Id,
                Title = Book.Title,
                Author = Book.Author,
                PublicationYear = Book.PublicationYear,
                Genre = Book.Genre
            };

            if(Book.Id == 0)
            {
                _bookRepository.Add(book);
            }
            else
            {
                _bookRepository.Update(book);
            }

            return RedirectToPage("Index");
        }
    }
}
