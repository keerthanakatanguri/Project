using DemoRazorApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.JSInterop;

namespace DemoRazorApp.Pages
{
    [IgnoreAntiforgeryToken]
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;
        private BookRepository _bookRepository;
        public List<TblBook> Books { get; set; }

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
            _bookRepository = new BookRepository();
        }

        public void OnGet()
        {
            Books = _bookRepository.GetAll().ToList();
        }

        public IActionResult OnPostDeleteBook(int id)
        {
            return new JsonResult(_bookRepository.Delete(id));
        }
    }
}
